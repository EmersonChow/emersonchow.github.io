
<h1>How To Run (Requirements)</h1>
1. Go to http://circinus-28.ics.uci.edu:8080/project1/ <br>
2. Set your mailto: default program to preferred mail client: highly recommend not using in browser client, use external mail client like Mail for Windows or Apple Mail for Mac<br>
<h1>Main Page</h1>
  Requirement 1: See the Sidebar <br>
  Requirement 2, 3, 4: See the Car Table <br>
  Requirement 5: Click on any image in the car table <br>
  Requirement 6: Click the "Order now" button and fill out the form <br>
  Requirement 7: Click the "Submit" button and make sure you followed the instructions on how to run above <br>
  Requirement 8: Enter for example blank values into the fields and the form will alert you to fill out all fields. <br>
  Requirement 9: See the main page and the car info page to see 10+ stylistic properties <br>
  Requirement 10: Mouse over the images in the main page table and see the images get larger <br> 
  Requirement 11: Names and Student ID of group members is in the Sidebar section "Contact Info" <br>
  
 <h1>Group Members</h1>
 Christopher Ye: 93031221 <br>
 Zhen Li: 84257555 <br>
 Emerson Chow: 29527073 <br>
 Luke Falcone: 26133003 <br>
